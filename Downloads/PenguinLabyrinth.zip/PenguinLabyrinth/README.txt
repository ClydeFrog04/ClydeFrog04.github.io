This game was developed by Randal Egan for CSC200. All code written is my own. All art was found online, being used under fair use for school. This game is not being sold, and is available completely for free as part of the EULA with Unity personal.

All controls can be found in-game. Press Q anytime during gameplay to return to the main menu.

This is not quite finished being developed, but such is the life of a programmer to retire a project for a while to work on other things, so here is my almost complete game! I recommend plugging in some music or watching tv as there is currently no sound in the game. Hope you enjoy! 


Any comments or questions can be sent via email to travelingmercdesigns@gmail.com